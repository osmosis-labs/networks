<!--
order: 0
title: "Pool Incentives Overview"
parent:
  title: "pool incentives"
-->

# `pool incentives`

## Abstract

The purpose of the `pool incentives` module is to distribute incentives to the pool LPs within the `Gamm` module.
