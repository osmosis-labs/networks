<!--
order: 3
-->

# Messages

This details the types of messages supported by the x/gamm module.

## MsgCreatePool

Message create pool allows for creation of a pool.

TODO