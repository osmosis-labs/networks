package types

// claim module event typs
const (
	EventTypeClaim = "claim"
)
