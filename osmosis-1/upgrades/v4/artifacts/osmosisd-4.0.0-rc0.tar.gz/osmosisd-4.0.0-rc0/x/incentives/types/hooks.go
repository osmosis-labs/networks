package types

import sdk "github.com/cosmos/cosmos-sdk/types"

type IncentiveHooks interface {
	AfterCreateGauge(ctx sdk.Context, gaugeId uint64)
	AfterAddToGauge(ctx sdk.Context, gaugeId uint64)
	AfterStartDistribution(ctx sdk.Context, gaugeId uint64)
	AfterFinishDistribution(ctx sdk.Context, gaugeId uint64)
	AfterDistribute(ctx sdk.Context, gaugeId uint64)
}

var _ IncentiveHooks = MultiIncentiveHooks{}

// combine multiple incentive hooks, all hook functions are run in array sequence
type MultiIncentiveHooks []IncentiveHooks

func NewMultiIncentiveHooks(hooks ...IncentiveHooks) MultiIncentiveHooks {
	return hooks
}

func (h MultiIncentiveHooks) AfterCreateGauge(ctx sdk.Context, gaugeId uint64) {
	for i := range h {
		h[i].AfterCreateGauge(ctx, gaugeId)
	}
}

func (h MultiIncentiveHooks) AfterAddToGauge(ctx sdk.Context, gaugeId uint64) {
	for i := range h {
		h[i].AfterAddToGauge(ctx, gaugeId)
	}
}

func (h MultiIncentiveHooks) AfterStartDistribution(ctx sdk.Context, gaugeId uint64) {
	for i := range h {
		h[i].AfterStartDistribution(ctx, gaugeId)
	}
}

func (h MultiIncentiveHooks) AfterFinishDistribution(ctx sdk.Context, gaugeId uint64) {
	for i := range h {
		h[i].AfterFinishDistribution(ctx, gaugeId)
	}
}

func (h MultiIncentiveHooks) AfterDistribute(ctx sdk.Context, gaugeId uint64) {
	for i := range h {
		h[i].AfterDistribute(ctx, gaugeId)
	}
}
