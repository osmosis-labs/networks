package types

// Minting module event types
const (
	EventTypeMint = ModuleName

	AttributeKeyEpochProvisions = "epoch_provisions"
	AttributeEpochNumber        = "epoch_number"
)
