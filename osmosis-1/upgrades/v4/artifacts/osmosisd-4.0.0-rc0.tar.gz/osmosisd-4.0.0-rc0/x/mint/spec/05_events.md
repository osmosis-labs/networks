<!--
order: 5
-->

# Events

The minting module emits the following events:

## End of Epoch

| Type | Attribute Key    | Attribute Value   |
| ---- | ---------------- | ----------------- |
| mint | epoch_number     | {epochNumber}     |
| mint | epoch_provisions | {epochProvisions} |
| mint | amount           | {amount}          |
