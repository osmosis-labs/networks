// Package conv provides internal functions for convertions and data manipulation
package conv
